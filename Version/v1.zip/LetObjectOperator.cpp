#include "LetManager.h"
#include "LetObject.h"
#include <string>
#include <functional>

using namespace Cervice::Obj;

// ������ֵ
LetObject* LetObject::operator<<(long long int num)
{
	return operator<<((long double)num);
}

LetObject* LetObject::operator<<(int num)
{
	return operator<<((long long int)num);
}

LetObject* LetObject::operator<<(long double num)
{
	OBJ_IF_CALL(!m_block, create(StaticB));
	changeBlock(StaticB);

	auto self = m_block->ptr;
	*(doublePtr)self = num;

	setType({ ObjT::number, ObjG::Static });
	return this;
}

LetObject* LetObject::operator<<(double num)
{
	return operator<<((long double)num);
}

LetObject* LetObject::operator<<(bool num)
{
	OBJ_IF_CALL(!m_block, create(StaticB));
	changeBlock(StaticB);

	auto self = m_block->ptr;
	*(boolPtr)self = num;

	setType({ ObjT::boolean, ObjG::Static });
	return this;
}

LetObject* LetObject::operator<<(const char* str)
{
	size_t lens = strnlen_s(str, UINT64_MAX);
	OBJ_IF_CALL(!m_block, create(DynamicB));

	changeBlock(DynamicB);
	if (lens > m_block->lens) {
		m_letM->realloc_L(&m_block, lens);
	}

	memcpy(m_block->ptr, str, lens);

	m_block->ptr[lens] = '\0';
	m_block->ptr[m_block->lens] = '\0';

	setType({ ObjT::string, ObjG::Dynamic });
	return this;
}

LetObject* LetObject::operator<<(std::string str)
{
	return operator<<(str.c_str());
}

// ������ֵ
LetObject* LetObject::operator=(const LetObject& node)
{
	do 
	{
		auto selfS = m_objType;
		auto otheS = node.m_objType;

		OBJ_IFB_CALL(otheS.type == ObjT::null, released());
		OBJ_IF_CALL(selfS.type == ObjT::null, create(otheS.group == ObjG::Static ? true : false));

		if (node.m_block->lens > m_block->lens) {
			m_letM->realloc_L(&m_block, node.m_block->lens);
		}

		auto selfL = m_block->lens;
		auto otheL = node.m_block->lens;

		auto self = m_block->ptr;
		auto othe = node.m_block->ptr;

		m_num_array.clear();
		m_str_array.clear();
		
		for (auto& i : node.m_num_array) {
			m_num_array[i.first] = i.second;
		}

		for (auto& i : node.m_str_array) {
			m_str_array[i.first] = i.second;
		}

		
		switch (otheS.type)
		{
		case LetObject::ObjT::undef:
			break;
		case LetObject::ObjT::boolean:
		case LetObject::ObjT::number:
			*(doublePtr)self = *(doublePtr)othe;
			break;
		case LetObject::ObjT::string: {
			size_t rlens = strnlen_s(othe, otheL);
			memcpy(self, othe, rlens);
			self[rlens] = '\0';
			self[m_block->lens] = '\0';
		}
		default:
			break;
		}

		setType(node.m_objType);

	}
	while (false);

	this->Attribute = node.Attribute;
	return this;
}

LetObject* LetObject::operator=(const LetObject* node)
{
	return operator=(*node);
}


LetObject& LetObject::operator[](const LetObject* node)
{
	if (node == nullptr || 
		node->m_objType.group == ObjG::none || 
		node->m_objType.type == ObjT::null || 
		node->m_objType.type == ObjT::undef) {
		throw("index only can take Number or String");
	}

	LetObject* ret = nullptr;

	auto selfS = m_objType;
	OBJ_IF_CALL(selfS.type == ObjT::null, create(StaticB));

	m_letM->realloc_L(&m_block, 8);

	auto nodeS = node->m_objType;
	if (nodeS.group == ObjG::Static) {
		ret = &m_num_array[cast<double>(const_cast<LetObject*>(node))];
	}
	else if (nodeS.group == ObjG::Dynamic) {
		ret = &m_str_array[std::move(cast<std::string>(const_cast<LetObject*>(node)))];
	}

	setType({ ObjT::array,ObjG::Static });

	return *ret;
}

LetObject& LetObject::operator[](const LetObject& node)
{
	return operator[](&node);
}

LetObject& LetObject::operator[](const char* cstr)
{
	std::string str;
	str.append(cstr);
	return operator[]<std::string>(str);
}

LetObject LetObject::operator+(const LetObject& node)
{
	return operator+(&node);
}

LetObject LetObject::operator+(const LetObject* node)
{
	LetObject ret(false, false);

	do
	{
		auto selfS = m_objType;
		auto otheS = node->m_objType;

		OBJ_IF_BREAK(otheS.type == ObjT::null || otheS.type == ObjT::undef);
		OBJ_IF_BREAK(selfS.type == ObjT::null || selfS.type == ObjT::undef);

		auto selfL = m_block->lens;
		auto otheL = node->m_block->lens;

		auto selfST = selfS.type;
		auto otheST = otheS.type;

		auto self = m_block->ptr;
		auto othe = node->m_block->ptr;

		// ͬ������� ���� �ַ��� ����
		if (isSameAs(selfST, otheST) ||
			(isLess(otheST, ObjT::string) && isLess(selfST, ObjT::string))
			)
		{
			switch (selfS.type)
			{
			case LetObject::ObjT::boolean:
			case LetObject::ObjT::number:
			{
				ret.create(StaticB);
				auto result = ret.m_block->ptr;
				*(doublePtr)result = *(doublePtr)self + *(doublePtr)othe;
			}
			break;
			case LetObject::ObjT::string:
			{
				size_t lensS = strnlen_s(self, selfL);
				size_t lensO = strnlen_s(othe, otheL);
				ret.create(DynamicB);
				if (lensS + lensO > ret.m_block->lens) {
					m_letM->realloc_L(&ret.m_block, lensS + lensO);
				}
				auto result = ret.m_block->ptr;
				result = ret.m_block->ptr;
				memcpy(result, self, lensS);
				memcpy(result + lensS, othe, lensO);
				result[lensS + lensO] = '\0';
				result[ret.m_block->lens] = '\0';
			}
			break;
			case LetObject::ObjT::array:
			{
				ret.create(StaticB);
				for (auto& i : m_num_array)
					ret.m_num_array[i.first] = i.second;
				for (auto& i : m_str_array)
					ret.m_str_array[i.first] = i.second;
				for (auto& i : node->m_num_array)
					ret.m_num_array[i.first] = i.second;
				for (auto& i : node->m_str_array)
					ret.m_str_array[i.first] = i.second;
			}
			break;
			default:
				break;
			}
			ret.setType(m_objType);
		}

		// �ַ����������
		else if (isLess(otheST, ObjT::string) || isLess(selfST, ObjT::string) &&
			(isLess(otheST, ObjT::array) && isLess(selfST, ObjT::array)))
		{
			Block* numB = isLess(selfST, ObjT::string) ?  m_block : node->m_block;
			Block* strB = isLess(selfST, ObjT::string) ?  node->m_block : m_block;
			bool whoFirst =  (strB == m_block) ? true : false;

			std::string numC;
			numC = std::to_string(*(long double*)numB->ptr);

			size_t oneBT, twoBT;

			size_t offset = 0; auto iter = numC.rbegin();
			while (iter != numC.rend() && *iter == '0') {
				offset++; iter++;
			}

			numC = numC.substr(0,numC.size() - offset);
			oneBT = numC.length();

			twoBT = strnlen_s(strB->ptr, strB->lens);

			ret.create(DynamicB);
			if (oneBT + twoBT > ret.m_block->lens) {
				m_letM->realloc_L(&ret.m_block, oneBT + twoBT);
			}
			
			auto result = ret.m_block->ptr;
			result = ret.m_block->ptr;
			if (whoFirst) {
				memcpy(result, strB->ptr, twoBT);
				memcpy(result + twoBT, numC.c_str(), oneBT);
			}
			else {
				memcpy(result, numC.c_str(), oneBT);
				memcpy(result + oneBT, strB->ptr, twoBT);
			}
			result[oneBT+ twoBT] = '\0';
			result[ret.m_block->lens] = '\0';

			ret.setType({ ObjT::string,ObjG::Dynamic });
		}
		else {
			throw("Object : cant take Add");
		}

	} while (false);

	return std::move(ret);
}

LetObject LetObject::operator-(const LetObject& node)
{
	return operator-(&node);
}

LetObject LetObject::operator-(const LetObject* node)
{
	LetObject ret(false, false);

	do
	{
		auto selfS = m_objType;
		auto otheS = node->m_objType;

		OBJ_IF_BREAK(otheS.type == ObjT::null || otheS.type == ObjT::undef);
		OBJ_IF_BREAK(selfS.type == ObjT::null || selfS.type == ObjT::undef);

		auto selfL = m_block->lens;
		auto otheL = node->m_block->lens;

		auto selfST = selfS.type;
		auto otheST = otheS.type;

		auto self = m_block->ptr;
		auto othe = node->m_block->ptr;

		// ͬ������� ����
		if (isSameAs(selfST, otheST) &&
			(isLess(otheST, ObjT::string) && isLess(selfST, ObjT::string))
			)
		{
			switch (selfS.type)
			{
			case LetObject::ObjT::boolean:
			case LetObject::ObjT::number:
			{
				ret.create(StaticB);
				auto result = ret.m_block->ptr;
				*(doublePtr)result = *(doublePtr)self - *(doublePtr)othe;
			}
			break;
			default:
				break;
			}
			ret.setType(m_objType);
		}
		else {
			throw("Object : cant take Sub");
		}

	} while (false);

	return std::move(ret);
}


LetObject LetObject::operator*(const LetObject& node)
{
	return operator*(&node);
}

LetObject LetObject::operator*(const LetObject* node)
{
	LetObject ret(false, false);

	do
	{
		auto selfS = m_objType;
		auto otheS = node->m_objType;

		OBJ_IF_BREAK(otheS.type == ObjT::null || otheS.type == ObjT::undef);
		OBJ_IF_BREAK(selfS.type == ObjT::null || selfS.type == ObjT::undef);

		auto selfL = m_block->lens;
		auto otheL = node->m_block->lens;

		auto selfST = selfS.type;
		auto otheST = otheS.type;

		auto self = m_block->ptr;
		auto othe = node->m_block->ptr;

		// ͬ������� ����
		if (isSameAs(selfST, otheST) &&
			(isLess(otheST, ObjT::string) && isLess(selfST, ObjT::string))
			)
		{
			switch (selfS.type)
			{
			case LetObject::ObjT::boolean:
			case LetObject::ObjT::number:
			{
				ret.create(StaticB);
				auto result = ret.m_block->ptr;
				*(doublePtr)result = *(doublePtr)self * *(doublePtr)othe;
			}
			break;
			default:
				break;
			}
			ret.setType(m_objType);
		}
		else {
			throw("Object : cant take Mul");
		}

	} while (false);

	return std::move(ret);
}

LetObject LetObject::operator/(const LetObject& node)
{
	return operator/(&node);
}

LetObject LetObject::operator/(const LetObject* node)
{
	LetObject ret(false, false);

	do
	{
		auto selfS = m_objType;
		auto otheS = node->m_objType;

		OBJ_IF_BREAK(otheS.type == ObjT::null || otheS.type == ObjT::undef);
		OBJ_IF_BREAK(selfS.type == ObjT::null || selfS.type == ObjT::undef);

		auto selfL = m_block->lens;
		auto otheL = node->m_block->lens;

		auto selfST = selfS.type;
		auto otheST = otheS.type;

		auto self = m_block->ptr;
		auto othe = node->m_block->ptr;

		// ͬ������� ����
		if (isSameAs(selfST, otheST) &&
			(isLess(otheST, ObjT::string) && isLess(selfST, ObjT::string))
			)
		{
			switch (selfS.type)
			{
			case LetObject::ObjT::boolean:
			case LetObject::ObjT::number:
			{
				ret.create(StaticB);
				auto result = ret.m_block->ptr;
				OBJ_IFB_CALL(*(doublePtr)self == 0.0, ret.released());
				*(doublePtr)result = *(doublePtr)self / *(doublePtr)othe;
			}
			break;
			default:
				break;
			}
			ret.setType(m_objType);
		}
		else {
			throw("Object : cant take Div");
		}

	} while (false);

	return std::move(ret);
}
